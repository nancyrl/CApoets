Given /I am a user on the "(.*)" page who wants to "(.*)"/ do |page, action|
    pending
end

Then /I should see input boxes labeled with the following: "(.*)"/ do |label|
   pending 
end

Then /I should see "(.*)"/ do |msg|
    pending
end

And /I press "(.*)"/ do |submit|
    pending
end

And /I can fill in input box "(.*)" with "(.*)"/ do |input, value|
    pending
end

Then /the "(.*)" field should contain "(.*)"/ do |input, value|
    pending
end

When /I press "(.*)"/ do |button|
    pending
end

And /I attach "(.*)" with "(.*)"/ do |input, value|
    pending
end

Then /I should be on new poem/ do
    pending
end