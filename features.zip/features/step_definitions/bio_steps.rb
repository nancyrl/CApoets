Given /I am a writer on the "(.*)" page/ do |page|
    pending
end

Then /I press the "(.*)" button/ do |button|
    pending
end

Then /I should see input boxes labeled with the following: "(.*)"/ do |labels|
    pending
end