Given /I am a reader on the "(.*)" page/ do |page|
    pending
end

Then /I should see a feed/ do
    pending
end