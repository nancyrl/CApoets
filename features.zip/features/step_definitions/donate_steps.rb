Given /I am a reader on the "(.*)" page/ do |page|
    pending
end

Then /I should see a the "(.*)" button/ do |page|
    pending
end