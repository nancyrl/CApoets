Given /I am a reader on the "(.*)" page who wants to "(.*)"/ do |page, action|
    pending
end

Then /I press the "(.*)" button/ do |button|
    pending
end

Then /I should see a "(.*)" page/ do |page|
    pending
end

And /poem in the "(.*)" page should have tags similar to the "(.*)" page/ do |page, page2|
    pending
end
