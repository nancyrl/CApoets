Given /I am a user on the "(.*)" page who wants to "(.*)"/ do |page, action|
    pending
end

Then /I should see input boxes labeled with the following: "(.*)"/ do |tags|
    pending
end

Then /I should see input boxes labeled with the following: "(.*)"/ do |box|
    pending
end

Then /I should see a drop down menu with options: "(.*)"/ do |labels|
    pending
end

And /I can select "(.*)"/ do |label|
    pending
end

Given /exists a poem with tags: "(.*)"/ do |labels|
    pending
end

Then /I should see a poem with tags: "(.*)"/ do |labels|
    pending
end
